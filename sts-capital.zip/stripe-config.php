<?php
/**
 * ARQUIVO DE SEGURANÇA: NÃO ENVIAR PARA O GIT
 * Contém as chaves reais do Stripe.
 */
if (!defined('STRIPE_PUBLISHABLE_KEY')) {
    define('STRIPE_PUBLISHABLE_KEY', 'pk_live_51TL0PTKhmaGEKbR2MmT4Hk1tPm2KFexkgXqMBcfS927owqPxkgaNOG4pzkpXCm6nLl8I4WsvwHrtKMEdPmaz0xgy00rnwfEtNI');
}

if (!defined('STRIPE_SECRET_KEY')) {
    define('STRIPE_SECRET_KEY', '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');
}

if (!defined('STRIPE_PRICE_ID')) {
    define('STRIPE_PRICE_ID', 'price_1TL0mqKhmaGEKbR21WrvU9ZM');
}
